package com.example.merahisaab;

import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.speech.RecognizerIntent;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db; EditText name, amount, note; Spinner type; TextView summary, entries;
    static final int SPEECH=77;
    public void onCreate(Bundle b) {
        super.onCreate(b); db=new DB(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(24,24,24,24);
        root.setBackgroundColor(0xFFF7F8FA);
        TextView title=new TextView(this); title.setText("मेरा रोज़ का हिसाब"); title.setTextSize(26); title.setTextColor(0xFF183528); title.setPadding(0,0,0,18); root.addView(title);
        summary=new TextView(this); summary.setTextSize(18); summary.setPadding(0,8,0,18); root.addView(summary);
        name=new EditText(this); name.setHint("खाते का नाम (जैसे आशी)"); root.addView(name);
        amount=new EditText(this); amount.setHint("रकम रुपये में"); amount.setInputType(2); root.addView(amount);
        type=new Spinner(this); String[] kinds={"खर्च","जमा","उधार दिया","उधार मिला"}; type.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,kinds)); root.addView(type);
        note=new EditText(this); note.setHint("विवरण (वैकल्पिक)"); root.addView(note);
        Button save=new Button(this); save.setText("एंट्री सेव करें"); save.setOnClickListener(v->saveEntry()); root.addView(save);
        Button voice=new Button(this); voice.setText("🎙️ बोलकर एंट्री लिखें"); voice.setOnClickListener(v->speak()); root.addView(voice);
        Button backup=new Button(this); backup.setText("बैकअप एक्सपोर्ट करें"); backup.setOnClickListener(v->exportBackup()); root.addView(backup);
        Button refresh=new Button(this); refresh.setText("हिसाब रीफ्रेश करें"); refresh.setOnClickListener(v->refresh()); root.addView(refresh);
        ScrollView sc=new ScrollView(this); entries=new TextView(this); entries.setTextSize(16); entries.setPadding(0,18,0,0); sc.addView(entries); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        if(Intent.ACTION_SEND.equals(getIntent().getAction())) { String s=getIntent().getStringExtra(Intent.EXTRA_TEXT); if(s!=null) parseCommand(s); }
        refresh();
    }
    void saveEntry() {
        String n=name.getText().toString().trim(), a=amount.getText().toString().trim();
        if(n.isEmpty()||a.isEmpty()){toast("खाते का नाम और रकम भरें");return;}
        try { db.add(n, type.getSelectedItem().toString(), Double.parseDouble(a), note.getText().toString()); name.setText("");amount.setText("");note.setText("");refresh();toast("एंट्री मोबाइल में सेव हो गई");}
        catch(Exception e){toast("रकम सही लिखें");}
    }
    void speak() {
        try { Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN"); i.putExtra(RecognizerIntent.EXTRA_PROMPT,"अपनी हिसाब की एंट्री बोलें"); startActivityForResult(i,SPEECH);}
        catch(Exception e){toast("इस मोबाइल में वॉइस टाइपिंग उपलब्ध नहीं है");}
    }
    protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==SPEECH&&c==RESULT_OK&&d!=null){ArrayList<String>x=d.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(x!=null&&!x.isEmpty())parseCommand(x.get(0));}}
    void parseCommand(String s) {
        // Accepts examples: "आशी के खाते में 100 रुपये खर्च", "आशी 100 जमा"
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("(.+?)\\s+(?:के खाते में\\s*)?(\\d+(?:\\.\\d+)?)\\s*(?:रुपये|रुपया|rs)?\\s*(खर्च|जमा|उधार दिया|उधार मिला)").matcher(s.trim());
        if(m.find()){name.setText(m.group(1).replace("के खाते में","").trim());amount.setText(m.group(2));String k=m.group(3);int idx=k.equals("खर्च")?0:k.equals("जमा")?1:k.equals("उधार दिया")?2:3;type.setSelection(idx);note.setText("वॉइस कमांड: "+s);toast("एंट्री जाँचकर सेव करें");}
        else {name.setText(s);toast("कमांड समझ नहीं आई; नाम, रकम और खर्च/जमा बोलें");}
    }
    void refresh() {
        Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*), COALESCE(SUM(CASE WHEN kind='जमा' OR kind='उधार मिला' THEN amount ELSE 0 END),0), COALESCE(SUM(CASE WHEN kind='खर्च' OR kind='उधार दिया' THEN amount ELSE 0 END),0) FROM tx",null);
        c.moveToFirst(); summary.setText("कुल एंट्री: "+c.getInt(0)+"    जमा: ₹"+c.getDouble(1)+"    खर्च/दिया: ₹"+c.getDouble(2));c.close();
        Cursor x=db.getReadableDatabase().rawQuery("SELECT person,kind,amount,note,created FROM tx ORDER BY id DESC LIMIT 100",null);
        StringBuilder b=new StringBuilder("हाल की एंट्री\n\n");while(x.moveToNext()){b.append(x.getString(0)).append(" • ").append(x.getString(1)).append(" • ₹").append(x.getDouble(2)).append("\n").append(x.getString(3)).append("\n").append(x.getString(4)).append("\n\n");}x.close();entries.setText(b.toString());
    }
    void exportBackup(){Cursor c=db.getReadableDatabase().rawQuery("SELECT person,kind,amount,note,created FROM tx ORDER BY id",null);StringBuilder s=new StringBuilder("खाता,प्रकार,रकम,विवरण,तारीख\n");while(c.moveToNext()){for(int i=0;i<5;i++){if(i>0)s.append(",");s.append("\"").append(c.getString(i)==null?"":c.getString(i).replace("\"","\"\"")).append("\"");}s.append("\n");}c.close();Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/csv");send.putExtra(Intent.EXTRA_SUBJECT,"मेरा हिसाब बैकअप");send.putExtra(Intent.EXTRA_TEXT,s.toString());startActivity(Intent.createChooser(send,"बैकअप शेयर/सेव करें"));}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"hisab_local.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, person TEXT, kind TEXT, amount REAL, note TEXT, created TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
        void add(String p,String k,double a,String note){ContentValues v=new ContentValues();v.put("person",p);v.put("kind",k);v.put("amount",a);v.put("note",note);v.put("created",new SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date()));getWritableDatabase().insert("tx",null,v);}
    }
}
